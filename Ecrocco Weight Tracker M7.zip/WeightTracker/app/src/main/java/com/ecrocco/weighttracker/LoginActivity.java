package com.ecrocco.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.ecrocco.weighttracker.model.User;
import com.ecrocco.weighttracker.viewmodel.LoginViewModel;

public class LoginActivity extends AppCompatActivity {
    private final LoginViewModel mViewModel = new LoginViewModel();
    private ViewSwitcher viewSwitcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login_or_signup);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void loginSubmit(View view) {
        TextView usernameText = findViewById(R.id.loginUsername);
        TextView passwordText = findViewById(R.id.loginPassword);

        String username = usernameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter your username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = mViewModel.login(this, username, password);
        if (user != null) {
            Intent intent = new Intent(this, DashboardActivity.class);
            intent.putExtra("userId", user.getId());
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    public void goToSignup(View view) {
        startActivity(new Intent(this, SignupActivity.class));
    }


}
