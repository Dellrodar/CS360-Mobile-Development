package com.ecrocco.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ecrocco.weighttracker.viewmodel.SetupViewModel;

public class SetupActivity extends AppCompatActivity {
    private final SetupViewModel mViewModel = new SetupViewModel();
    private long mUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setup);
        mUserId = getIntent().getLongExtra("userId", -1);
    }

    public void saveGoalWeight(View view) {
        EditText goalInput = findViewById(R.id.goalWeightInput);
        String goalStr = goalInput.getText().toString().trim();

        if (goalStr.isEmpty()) {
            Toast.makeText(this, "Please enter a goal weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        double goal;
        try {
            goal = Double.parseDouble(goalStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_SHORT).show();
            return;
        }

        mViewModel.saveGoalWeight(this, mUserId, goal);

        Intent intent = new Intent(this, DashboardActivity.class);
        intent.putExtra("userId", mUserId);
        // Clear the back stack so back button doesn't return to setup
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
