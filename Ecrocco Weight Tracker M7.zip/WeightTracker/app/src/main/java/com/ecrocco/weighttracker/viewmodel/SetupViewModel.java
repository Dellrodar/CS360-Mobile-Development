package com.ecrocco.weighttracker.viewmodel;

import android.content.Context;

import com.ecrocco.weighttracker.repo.WeightTrackerRepository;

public class SetupViewModel {

    public void saveGoalWeight(Context context, long userId, double goal) {
        WeightTrackerRepository.getInstance(context).setGoalWeight(userId, goal);
    }
}
