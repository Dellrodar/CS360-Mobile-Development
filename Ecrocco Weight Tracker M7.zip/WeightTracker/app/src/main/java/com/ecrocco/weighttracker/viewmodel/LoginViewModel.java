package com.ecrocco.weighttracker.viewmodel;

import android.content.Context;

import com.ecrocco.weighttracker.model.User;
import com.ecrocco.weighttracker.repo.WeightTrackerRepository;

public class LoginViewModel {

    public User login(Context context, String username, String password) {
        return WeightTrackerRepository.getInstance(context).getUser(username, password);
    }
}
