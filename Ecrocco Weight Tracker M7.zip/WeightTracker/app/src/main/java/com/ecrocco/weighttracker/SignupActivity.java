package com.ecrocco.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.ecrocco.weighttracker.model.User;
import com.ecrocco.weighttracker.viewmodel.SignupViewModel;

public class SignupActivity extends AppCompatActivity {
    private final SignupViewModel mViewModel = new SignupViewModel();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login_or_signup);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ViewSwitcher viewSwitcher = findViewById(R.id.loginSignupViewSwitcher);
        viewSwitcher.showNext();

        ImageButton backButton = findViewById(R.id.imageButton);
        backButton.setVisibility(View.VISIBLE);
        backButton.setOnClickListener(v -> goToLogin());
    }

    private void goToLogin() {
        ViewSwitcher viewSwitcher = findViewById(R.id.loginSignupViewSwitcher);
        viewSwitcher.showNext();
        startActivity(new Intent(this, LoginActivity.class));
    }

    public void signupSubmit(View view) {
        EditText nameText = findViewById(R.id.signupNameText);
        EditText emailText = findViewById(R.id.signupEmailAddress);
        EditText usernameText = findViewById(R.id.signupUsername);
        EditText passwordText = findViewById(R.id.signupPassword);

        String name = nameText.getText().toString().trim();
        String email = emailText.getText().toString().trim();
        String username = usernameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        if (name.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        User newUser = new User(email, name, username, password, 0, 0);
        long userId = mViewModel.createAccount(this, newUser);

        if (userId == -1) {
            Toast.makeText(this, "Username already taken. Please choose another.", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent(this, SetupActivity.class);
            intent.putExtra("userId", userId);
            startActivity(intent);
        }
    }
}
