package com.ecrocco.weighttracker.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.ecrocco.weighttracker.model.GoalWeight;
import com.ecrocco.weighttracker.model.User;
import com.ecrocco.weighttracker.model.WeightEntry;

import java.util.ArrayList;
import java.util.List;

public class WeightTrackerRepository {
    private static WeightTrackerRepository mWeightTrackerRepo;
    private final WeightTrackerDatabase mDatabase;

    private WeightTrackerRepository(Context context) {
        mDatabase = new WeightTrackerDatabase(context.getApplicationContext());
    }

    public static WeightTrackerRepository getInstance(Context context) {
        if (mWeightTrackerRepo == null) {
            mWeightTrackerRepo = new WeightTrackerRepository(context);
        }
        return mWeightTrackerRepo;
    }

    // --- User methods ---

    public long addUser(User user) {
        String salt = PasswordUtils.generateSalt();
        String passwordHash = PasswordUtils.hashPassword(user.getPassword(), salt);

        ContentValues values = new ContentValues();
        values.put(WeightTrackerDatabase.UserTable.COL_EMAIL, user.getEmail());
        values.put(WeightTrackerDatabase.UserTable.COL_NAME, user.getName());
        values.put(WeightTrackerDatabase.UserTable.COL_USERNAME, user.getUserName());
        values.put(WeightTrackerDatabase.UserTable.COL_PASSWORD_HASH, passwordHash);
        values.put(WeightTrackerDatabase.UserTable.COL_PASSWORD_SALT, salt);
        values.put(WeightTrackerDatabase.UserTable.COL_CURRENT_WEIGHT, user.getCurrentWeight());
        values.put(WeightTrackerDatabase.UserTable.COL_NOTIFICATIONS_ENABLED, user.isNotificationsEnabled() ? 1 : 0);

        SQLiteDatabase db = mDatabase.getWritableDatabase();
        return db.insertWithOnConflict(
                WeightTrackerDatabase.UserTable.TABLE,
                null,
                values,
                SQLiteDatabase.CONFLICT_IGNORE
        );
    }

    public User getUser(String username, String password) {
        SQLiteDatabase db = mDatabase.getReadableDatabase();
        try (Cursor cursor = db.query(
                WeightTrackerDatabase.UserTable.TABLE,
                null,
                WeightTrackerDatabase.UserTable.COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                String storedHash = cursor.getString(
                        cursor.getColumnIndexOrThrow(WeightTrackerDatabase.UserTable.COL_PASSWORD_HASH)
                );
                String storedSalt = cursor.getString(
                        cursor.getColumnIndexOrThrow(WeightTrackerDatabase.UserTable.COL_PASSWORD_SALT)
                );

                boolean isValid = PasswordUtils.verifyPassword(password, storedSalt, storedHash);
                if (!isValid) {
                    return null;
                }

                User user = new User(
                        cursor.getString(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.UserTable.COL_EMAIL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.UserTable.COL_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.UserTable.COL_USERNAME)),
                        "",
                        cursor.getDouble(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.UserTable.COL_CURRENT_WEIGHT)),
                        0
                );

                user.setId(cursor.getLong(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.UserTable.COL_ID)));
                user.setNotificationsEnabled(
                        cursor.getInt(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.UserTable.COL_NOTIFICATIONS_ENABLED)) == 1
                );
                return user;
            }
        }
        return null;
    }

    // --- Weight entry methods ---

    public void addWeightEntry(WeightEntry entry) {
        ContentValues values = new ContentValues();
        values.put(WeightTrackerDatabase.WeightHistoryTable.COL_USER_ID, entry.getUserId());
        values.put(WeightTrackerDatabase.WeightHistoryTable.COL_WEIGHT, entry.getWeight());
        values.put(WeightTrackerDatabase.WeightHistoryTable.COL_DATE, entry.getDate());
        SQLiteDatabase db = mDatabase.getWritableDatabase();
        db.insert(WeightTrackerDatabase.WeightHistoryTable.TABLE, null, values);
    }

    public List<WeightEntry> getWeightEntries(long userId) {
        List<WeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = mDatabase.getReadableDatabase();
        try (Cursor cursor = db.query(
                WeightTrackerDatabase.WeightHistoryTable.TABLE,
                null,
                WeightTrackerDatabase.WeightHistoryTable.COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null, null,
                WeightTrackerDatabase.WeightHistoryTable.COL_DATE + " DESC, " +
                        WeightTrackerDatabase.WeightHistoryTable.COL_ID + " DESC")) {
            while (cursor.moveToNext()) {
                WeightEntry entry = new WeightEntry(
                        cursor.getLong(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.WeightHistoryTable.COL_USER_ID)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.WeightHistoryTable.COL_WEIGHT)),
                        cursor.getLong(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.WeightHistoryTable.COL_DATE))
                );
                entry.setId(cursor.getLong(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.WeightHistoryTable.COL_ID)));
                entries.add(entry);
            }
        }
        return entries;
    }

    public WeightEntry getLastWeight(long userId) {
        SQLiteDatabase db = mDatabase.getReadableDatabase();

        try (Cursor cursor = db.query(
                WeightTrackerDatabase.WeightHistoryTable.TABLE,
                null,
                WeightTrackerDatabase.WeightHistoryTable.COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                WeightTrackerDatabase.WeightHistoryTable.COL_DATE + " DESC, " +
                        WeightTrackerDatabase.WeightHistoryTable.COL_ID + " DESC",
                "1")) {

            if (cursor.moveToFirst()) {
                WeightEntry entry = new WeightEntry(
                        cursor.getLong(cursor.getColumnIndexOrThrow(
                                WeightTrackerDatabase.WeightHistoryTable.COL_USER_ID)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(
                                WeightTrackerDatabase.WeightHistoryTable.COL_WEIGHT)),
                        cursor.getLong(cursor.getColumnIndexOrThrow(
                                WeightTrackerDatabase.WeightHistoryTable.COL_DATE))
                );

                entry.setId(cursor.getLong(cursor.getColumnIndexOrThrow(
                        WeightTrackerDatabase.WeightHistoryTable.COL_ID)));

                return entry;
            }
        }

        return null;
    }

    public void deleteWeightEntry(long id) {
        SQLiteDatabase db = mDatabase.getWritableDatabase();
        db.delete(
                WeightTrackerDatabase.WeightHistoryTable.TABLE,
                WeightTrackerDatabase.WeightHistoryTable.COL_ID + " = ?",
                new String[]{String.valueOf(id)});
    }

    // --- Goal weight methods ---

    public void setGoalWeight(long userId, double goal) {
        ContentValues values = new ContentValues();
        values.put(WeightTrackerDatabase.GoalWeightTable.COL_USER_ID, userId);
        values.put(WeightTrackerDatabase.GoalWeightTable.COL_GOAL, goal);
        SQLiteDatabase db = mDatabase.getWritableDatabase();
        // INSERT OR REPLACE since user_id is UNIQUE — creates or updates the goal
        db.insertWithOnConflict(
                WeightTrackerDatabase.GoalWeightTable.TABLE,
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE);
    }

    public GoalWeight getGoalWeight(long userId) {
        SQLiteDatabase db = mDatabase.getReadableDatabase();
        try (Cursor cursor = db.query(
                WeightTrackerDatabase.GoalWeightTable.TABLE,
                null,
                WeightTrackerDatabase.GoalWeightTable.COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null, null, null)) {
            if (cursor.moveToFirst()) {
                GoalWeight goal = new GoalWeight(
                        cursor.getLong(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.GoalWeightTable.COL_USER_ID)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.GoalWeightTable.COL_GOAL))
                );
                goal.setId(cursor.getLong(cursor.getColumnIndexOrThrow(WeightTrackerDatabase.GoalWeightTable.COL_ID)));
                return goal;
            }
        }
        return null;
    }

    public void setNotificationsEnabled(long userId, boolean enabled) {
        ContentValues values = new ContentValues();
        values.put(WeightTrackerDatabase.UserTable.COL_NOTIFICATIONS_ENABLED, enabled ? 1 : 0);
        SQLiteDatabase db = mDatabase.getWritableDatabase();
        db.update(WeightTrackerDatabase.UserTable.TABLE, values,
                WeightTrackerDatabase.UserTable.COL_ID + " = ?",
                new String[]{String.valueOf(userId)});
    }

    public boolean isNotificationsEnabled(long userId) {
        SQLiteDatabase db = mDatabase.getReadableDatabase();
        try (Cursor cursor = db.query(
                WeightTrackerDatabase.UserTable.TABLE,
                new String[]{WeightTrackerDatabase.UserTable.COL_NOTIFICATIONS_ENABLED},
                WeightTrackerDatabase.UserTable.COL_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getInt(0) == 1;
            }
        }
        return false;
    }
}
