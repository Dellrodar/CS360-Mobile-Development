package com.ecrocco.weighttracker.model;

public class WeightEntry {
    private long mId;
    private final long mUserId;
    private final double mWeight;
    private final long mDate;

    public WeightEntry(long userId, double weight, long date) {
        mUserId = userId;
        mWeight = weight;
        mDate = date;
    }

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getUserId() {
        return mUserId;
    }

    public double getWeight() {
        return mWeight;
    }

    public long getDate() {
        return mDate;
    }
}
