package com.ecrocco.weighttracker.repo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class WeightTrackerDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int VERSION = 5;

    public WeightTrackerDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    static final class UserTable {
        static final String TABLE = "users";
        static final String COL_ID = "_id";
        static final String COL_EMAIL = "email";
        static final String COL_NAME = "name";
        static final String COL_USERNAME = "username";
        static final String COL_PASSWORD_HASH = "password_hash";
        static final String COL_PASSWORD_SALT = "password_salt";
        static final String COL_CURRENT_WEIGHT = "weight";
        static final String COL_NOTIFICATIONS_ENABLED = "notifications_enabled";
    }

    static final class WeightHistoryTable {
        static final String TABLE = "weight";
        static final String COL_ID = "_id";
        static final String COL_USER_ID = "user_id";
        static final String COL_WEIGHT = "weight";
        static final String COL_DATE = "date";
    }

    static final class GoalWeightTable {
        static final String TABLE = "goal_weight";
        static final String COL_ID = "_id";
        static final String COL_USER_ID = "user_id";
        static final String COL_GOAL = "goal";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_EMAIL + " text, " +
                UserTable.COL_NAME + " text, " +
                UserTable.COL_USERNAME + " text unique, " +
                UserTable.COL_PASSWORD_HASH + " text, " +
                UserTable.COL_PASSWORD_SALT + " text, " +
                UserTable.COL_CURRENT_WEIGHT + " real, " +
                UserTable.COL_NOTIFICATIONS_ENABLED + " integer default 0)");

        db.execSQL("create table " + WeightHistoryTable.TABLE + " (" +
                WeightHistoryTable.COL_ID + " integer primary key autoincrement, " +
                WeightHistoryTable.COL_USER_ID + " integer, " +
                WeightHistoryTable.COL_WEIGHT + " real, " +
                WeightHistoryTable.COL_DATE + " integer)");

        db.execSQL("create table " + GoalWeightTable.TABLE + " (" +
                GoalWeightTable.COL_ID + " integer primary key autoincrement, " +
                GoalWeightTable.COL_USER_ID + " integer unique, " +
                GoalWeightTable.COL_GOAL + " real)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + WeightHistoryTable.TABLE);
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + GoalWeightTable.TABLE);
        onCreate(db);
    }
}
