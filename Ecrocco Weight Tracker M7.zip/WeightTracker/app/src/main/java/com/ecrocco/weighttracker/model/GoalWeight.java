package com.ecrocco.weighttracker.model;

public class GoalWeight {
    private long mId;
    private final long mUserId;
    private final double mGoal;

    public GoalWeight(long userId, double goal) {
        mUserId = userId;
        mGoal = goal;
    }

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getUserId() {
        return mUserId;
    }

    public double getGoal() {
        return mGoal;
    }
}
