package com.ecrocco.weighttracker.viewmodel;

import android.content.Context;

import com.ecrocco.weighttracker.model.User;
import com.ecrocco.weighttracker.repo.WeightTrackerRepository;

public class SignupViewModel {

    public long createAccount(Context context, User user) {
        return WeightTrackerRepository.getInstance(context).addUser(user);
    }
}
