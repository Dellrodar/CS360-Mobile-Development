package com.ecrocco.weighttracker.viewmodel;

import android.content.Context;

import com.ecrocco.weighttracker.model.GoalWeight;
import com.ecrocco.weighttracker.model.WeightEntry;
import com.ecrocco.weighttracker.repo.WeightTrackerRepository;

import java.util.List;

public class DashboardViewModel {

    public List<WeightEntry> getWeightEntries(Context context, long userId) {
        return WeightTrackerRepository.getInstance(context).getWeightEntries(userId);
    }

    public WeightEntry getLastWeight(Context context, long userId) {
        return WeightTrackerRepository.getInstance(context).getLastWeight(userId);
    }

    public void addWeightEntry(Context context, long userId, double weight, long date) {
        WeightEntry entry = new WeightEntry(userId, weight, date);
        WeightTrackerRepository.getInstance(context).addWeightEntry(entry);
    }

    public void deleteWeightEntry(Context context, long entryId) {
        WeightTrackerRepository.getInstance(context).deleteWeightEntry(entryId);
    }

    public GoalWeight getGoalWeight(Context context, long userId) {
        return WeightTrackerRepository.getInstance(context).getGoalWeight(userId);
    }

    public void updateGoalWeight(Context context, long userId, double goal) {
        WeightTrackerRepository.getInstance(context).setGoalWeight(userId, goal);
    }

    public boolean isNotificationsEnabled(Context context, long userId) {
        return WeightTrackerRepository.getInstance(context).isNotificationsEnabled(userId);
    }

    public void setNotificationsEnabled(Context context, long userId, boolean enabled) {
        WeightTrackerRepository.getInstance(context).setNotificationsEnabled(userId, enabled);
    }
}
