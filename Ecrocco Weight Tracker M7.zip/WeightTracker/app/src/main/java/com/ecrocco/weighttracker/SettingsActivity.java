package com.ecrocco.weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.ecrocco.weighttracker.model.GoalWeight;
import com.ecrocco.weighttracker.viewmodel.DashboardViewModel;

public class SettingsActivity extends AppCompatActivity {
    private final DashboardViewModel mViewModel = new DashboardViewModel();
    private long mUserId;
    private static final int NOTIFICATION_PERMISSION_REQUEST_CODE = 1002;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.settings);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.settings), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        mUserId = getIntent().getLongExtra("userId", -1);
        ImageButton backButton = findViewById(R.id.imageButton);
        backButton.setVisibility(View.VISIBLE);
        backButton.setOnClickListener(v -> goToDashboard());

        // Pre-fill current goal weight
        GoalWeight goal = mViewModel.getGoalWeight(this, mUserId);
        if (goal != null) {
            EditText goalInput = findViewById(R.id.goalWeightInput);
            if (goalInput != null) {
                goalInput.setText(String.valueOf(goal.getGoal()));
            }
        }

        // Load notification status
        updateNotificationStatusUi();
    }

    private void goToDashboard() {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();

        GoalWeight goal = mViewModel.getGoalWeight(this, mUserId);
        EditText goalInput = findViewById(R.id.goalWeightInput);
        if (goal != null && goalInput != null) {
            goalInput.setText(String.valueOf(goal.getGoal()));
        }

        updateNotificationStatusUi();
    }

    private void updateNotificationStatusUi() {
        TextView status = findViewById(R.id.notificationStatus);
        if (status == null) return;

        boolean isEnabled = mViewModel.isNotificationsEnabled(this, mUserId);
        status.setText(isEnabled ? R.string.status_on : R.string.status_off);
    }

    public void saveGoalWeight(View view) {
        EditText goalInput = findViewById(R.id.goalWeightInput);
        if (goalInput == null) return;

        String goalStr = goalInput.getText().toString().trim();
        if (goalStr.isEmpty()) {
            Toast.makeText(this, "Please enter a goal weight.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            double goal = Double.parseDouble(goalStr);
            mViewModel.updateGoalWeight(this, mUserId, goal);
            Toast.makeText(this, "Goal weight updated.", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_SHORT).show();
        }
    }

    public void toggleNotifications(View view) {
        boolean currentlyEnabled = mViewModel.isNotificationsEnabled(this, mUserId);

        // Turning OFF → always allowed
        if (currentlyEnabled) {
            mViewModel.setNotificationsEnabled(this, mUserId, false);
            updateNotificationStatusUi();
            Toast.makeText(this, "Notifications disabled.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Turning ON → check Android 13+ permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_REQUEST_CODE
                );
                return;
            }
        }

        // Permission already granted OR not required
        mViewModel.setNotificationsEnabled(this, mUserId, true);
        updateNotificationStatusUi();
        Toast.makeText(this, "Notifications enabled.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mViewModel.setNotificationsEnabled(this, mUserId, true);
                updateNotificationStatusUi();
                Toast.makeText(this, "Notifications enabled.", Toast.LENGTH_SHORT).show();
            } else {
                mViewModel.setNotificationsEnabled(this, mUserId, false);
                updateNotificationStatusUi();
                Toast.makeText(this, "Notification permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
