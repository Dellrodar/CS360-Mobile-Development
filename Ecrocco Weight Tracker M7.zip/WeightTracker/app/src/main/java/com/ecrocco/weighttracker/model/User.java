package com.ecrocco.weighttracker.model;

public class User {
    private long mId;
    private final String mEmail;
    private final String mName;
    private final String mUserName;
    private final String mPassword;
    private final double mCurrentWeight;
    private final double mCurrentGoal;
    private boolean mIsNotificationsEnabled;


    public User(String email, String name, String userName, String password,
                double currentWeight, double currentGoal) {
        mEmail = email;
        mName = name;
        mUserName = userName;
        mPassword = password;
        mCurrentWeight = currentWeight;
        mCurrentGoal = currentGoal;
        mIsNotificationsEnabled = false;
    }

    public long getId() {
        return mId;
    }

    public String getEmail() {
        return mEmail;
    }
    public String getName() {
        return mName;
    }
    public String getUserName() {
        return mUserName;
    }
    public double getCurrentWeight() {
        return mCurrentWeight;
    }

    public double getCurrentGoal() {
        return mCurrentGoal;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setId(long id) {
        mId = id;
    }

    public boolean isNotificationsEnabled() {
        return mIsNotificationsEnabled;
    }

    public void setNotificationsEnabled(boolean notificationsEnabled) {
        mIsNotificationsEnabled = notificationsEnabled;
    }
}
