package com.ecrocco.weighttracker;

import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.ecrocco.weighttracker.model.GoalWeight;
import com.ecrocco.weighttracker.model.WeightEntry;
import com.ecrocco.weighttracker.viewmodel.DashboardViewModel;
import com.google.android.material.navigationrail.NavigationRailView;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DashboardActivity extends AppCompatActivity {
    private static final String CHANNEL_ID = "goal_reached_channel";
    private static final int NOTIFICATION_ID = 1;

    private final DashboardViewModel mViewModel = new DashboardViewModel();
    private long mUserId;
    private TableLayout mWeightTable;
    private GraphView mGraph;
    private static final long ONE_DAY_MS = 86400000L;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.dashboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.dashboard), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        mUserId = getIntent().getLongExtra("userId", -1);
        mWeightTable = findViewById(R.id.weightHistoryTable);
        mGraph = findViewById(R.id.weightGraph);

        createNotificationChannel();
        setupNavigationRail();

        findViewById(R.id.addWeightButton).setOnClickListener(v -> showAddWeightDialog());

        refreshDashboard();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDashboard();
    }

    private void setupNavigationRail() {
        NavigationRailView navRail = findViewById(R.id.navigationRail);
        navRail.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.recordWeight) {
                showAddWeightDialog();
                return true;
            } else if (id == R.id.updateSettings) {
                Intent intent = new Intent(this, SettingsActivity.class);
                intent.putExtra("userId", mUserId);
                startActivity(intent);
                return true;
            } else if (id == R.id.logout) {
                Intent intent = new Intent(this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                return true;
            }
            return false;
        });
    }

    private void refreshDashboard() {
        List<WeightEntry> entries = mViewModel.getWeightEntries(this, mUserId);
        populateTable(entries);
        populateGraph(entries);
    }

    // --- Weight history table ---

    private void populateTable(List<WeightEntry> entries) {
        // Remove all rows except the header row (index 0) and its divider (index 1)
        while (mWeightTable.getChildCount() > 2) {
            mWeightTable.removeViewAt(2);
        }

        SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy", Locale.US);

        for (int i = 0; i < entries.size(); i++) {
            WeightEntry entry = entries.get(i);

            // Divider before each row
            View divider = new View(this);
            TableRow.LayoutParams dividerParams = new TableRow.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT, 1);
            divider.setLayoutParams(dividerParams);
            divider.setBackgroundColor(0xFFDDDDDD);
            mWeightTable.addView(divider);

            TableRow row = new TableRow(this);

            // Delete button
            ImageButton deleteBtn = new ImageButton(this);
            deleteBtn.setImageResource(R.drawable.remove_48px);
            deleteBtn.setBackground(null);
            TableRow.LayoutParams btnParams = new TableRow.LayoutParams(64, 64);
            btnParams.gravity = android.view.Gravity.CENTER_VERTICAL;
            deleteBtn.setLayoutParams(btnParams);
            deleteBtn.setScaleX(0.5f);
            deleteBtn.setScaleY(0.5f);
            deleteBtn.setContentDescription("Delete");
            final long entryId = entry.getId();
            deleteBtn.setOnClickListener(v -> {
                mViewModel.deleteWeightEntry(this, entryId);
                refreshDashboard();
            });

            // Date
            TextView dateText = new TextView(this);
            dateText.setText(sdf.format(new Date(entry.getDate())));
            TableRow.LayoutParams dateParams = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1.2f);
            dateParams.gravity = android.view.Gravity.CENTER_VERTICAL;
            dateText.setLayoutParams(dateParams);
            dateText.setPadding(12, 20, 12, 20);

            // Weight
            TextView weightText = new TextView(this);
            weightText.setText(String.format(Locale.US, "%.1f lbs", entry.getWeight()));
            TableRow.LayoutParams weightParams = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f);
            weightParams.gravity = android.view.Gravity.CENTER_VERTICAL;
            weightText.setLayoutParams(weightParams);
            weightText.setGravity(android.view.Gravity.CENTER);
            weightText.setPadding(12, 20, 12, 20);

            // Change vs previous entry (entries are newest-first, so next index is older)
            TextView changeText = new TextView(this);
            if (i + 1 < entries.size()) {
                double delta = entry.getWeight() - entries.get(i + 1).getWeight();
                String sign = delta >= 0 ? "+" : "";
                changeText.setText(String.format(Locale.US, "%s%.1f lb", sign, delta));
            } else {
                changeText.setText("—");
            }
            TableRow.LayoutParams changeParams = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f);
            changeParams.gravity = android.view.Gravity.CENTER_VERTICAL;
            changeText.setLayoutParams(changeParams);
            changeText.setGravity(android.view.Gravity.END);
            changeText.setPadding(12, 20, 12, 20);

            row.addView(deleteBtn);
            row.addView(dateText);
            row.addView(weightText);
            row.addView(changeText);
            mWeightTable.addView(row);
        }
    }

    // --- Graph ---
    private void populateGraph(List<WeightEntry> entries) {
        mGraph.removeAllSeries();
        mGraph.getViewport().setXAxisBoundsManual(false);
        mGraph.getViewport().setYAxisBoundsManual(false);
        mGraph.getGridLabelRenderer().setNumVerticalLabels(5);

        SimpleDateFormat sdf = new SimpleDateFormat("M/d", Locale.US);
        mGraph.getGridLabelRenderer().setLabelFormatter(
                new com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter(this, sdf)
        );

        long today = getStartOfDay(System.currentTimeMillis());

        if (entries.isEmpty()) {
            mGraph.getViewport().setMinX(today);
            mGraph.getViewport().setMaxX(today + (2 * ONE_DAY_MS));
            mGraph.getViewport().setXAxisBoundsManual(true);
            mGraph.getGridLabelRenderer().setNumHorizontalLabels(3);
            return;
        }

        // Oldest -> newest
        Map<Long, Integer> dayCounts = new HashMap<>();
        for (WeightEntry entry : entries) {
            long day = getStartOfDay(entry.getDate());
            dayCounts.compute(day, (k, count) -> (count != null) ? count + 1 : 1);
        }

        Map<Long, Integer> daySeen = new HashMap<>();

        DataPoint[] points = new DataPoint[entries.size()];
        for (int i = 0; i < entries.size(); i++) {
            WeightEntry e = entries.get(entries.size() - 1 - i);

            long day = getStartOfDay(e.getDate());

            Integer seen = daySeen.get(day);
            int seenIndex = (seen != null) ? seen : 0;
            daySeen.put(day, seenIndex + 1);

            Integer total = dayCounts.get(day);
            int totalForDay = (total != null) ? total : 1;

            long adjustedTime;
            if (totalForDay == 1) {
                adjustedTime = day + (ONE_DAY_MS / 2);
            } else {
                long spacing = ONE_DAY_MS / (totalForDay + 1);
                adjustedTime = day + ((long) (seenIndex + 1) * spacing);
            }

            points[i] = new DataPoint(adjustedTime, e.getWeight());
        }

        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(points);
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(8);
        series.setThickness(6);
        mGraph.addSeries(series);

        long entryDate = getStartOfDay((long) points[0].getX());
        long lastDate = getStartOfDay((long) points[points.length - 1].getX());

        double minX;
        double maxX;

        if (points.length >= 3) {
            // New rule:
            // If we already have at least 3 actual points, use the real date range,
            // even if multiple points fall on the same day.
            minX = entryDate;
            maxX = lastDate;

            // If all 3+ points are on the same day, widen the axis so date labels still render cleanly.
            if (entryDate == lastDate) {
                minX = entryDate;
                maxX = entryDate + (2 * ONE_DAY_MS);
            }

            mGraph.getGridLabelRenderer().setNumHorizontalLabels(3);

        } else if (points.length == 2) {
            if (entryDate == lastDate) {
                // Two entries on same day, widen to 3 visible dates
                minX = entryDate;
                maxX = entryDate + (2 * ONE_DAY_MS);
            } else {
                // Two different dates, use actual span
                minX = entryDate;

                // Optional stretch so axis reaches today if data is older
                maxX = Math.max(lastDate, today);
            }

            mGraph.getGridLabelRenderer().setNumHorizontalLabels(3);

        } else {
            // Single-point rules
            long diffDays = Math.max(0, (today - entryDate) / ONE_DAY_MS);

            if (entryDate == today) {
                minX = today;
                maxX = today + (2 * ONE_DAY_MS);
            } else if (diffDays == 1) {
                minX = entryDate;
                maxX = today + ONE_DAY_MS;
            } else if (diffDays >= 2) {
                minX = entryDate;
                maxX = today;
            } else {
                // future fallback
                minX = entryDate;
                maxX = entryDate + (2 * ONE_DAY_MS);
            }

            mGraph.getGridLabelRenderer().setNumHorizontalLabels(3);
        }

        mGraph.getViewport().setMinX(minX);
        mGraph.getViewport().setMaxX(maxX);
        mGraph.getViewport().setXAxisBoundsManual(true);

        double minY = points[0].getY();
        double maxY = points[0].getY();

        for (DataPoint point : points) {
            minY = Math.min(minY, point.getY());
            maxY = Math.max(maxY, point.getY());
        }

        // Add a little padding so the line is not touching the top/bottom
        double padding = Math.max(5.0, (maxY - minY) * 0.15);

        mGraph.getViewport().setMinY(minY - padding);
        mGraph.getViewport().setMaxY(maxY + padding);
        mGraph.getViewport().setYAxisBoundsManual(true);
        mGraph.getGridLabelRenderer().setNumVerticalLabels(5);

        GoalWeight goal = mViewModel.getGoalWeight(this, mUserId);
        if (goal != null) {
            DataPoint[] goalPoints = {
                    new DataPoint(minX, goal.getGoal()),
                    new DataPoint(maxX, goal.getGoal())
            };

            LineGraphSeries<DataPoint> goalSeries = new LineGraphSeries<>(goalPoints);
            goalSeries.setColor(0xFFE53935);
            goalSeries.setThickness(4);
            mGraph.addSeries(goalSeries);
        }
    }

    private long getStartOfDay(long timestamp) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestamp);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    // --- Add weight dialog ---

    private void showAddWeightDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_weight, null);
        EditText dateInput = dialogView.findViewById(R.id.dateInput);
        EditText weightInput = dialogView.findViewById(R.id.weightInput);


        final long[] selectedDate = {System.currentTimeMillis()};
        SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy", Locale.US);
        dateInput.setText(sdf.format(new Date(selectedDate[0])));

        dateInput.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(selectedDate[0]);
            new DatePickerDialog(this, (picker, year, month, day) -> {
                Calendar selected = Calendar.getInstance();
                selected.setTimeInMillis(selectedDate[0]);
                selected.set(Calendar.YEAR, year);
                selected.set(Calendar.MONTH, month);
                selected.set(Calendar.DAY_OF_MONTH, day);
                selectedDate[0] = selected.getTimeInMillis();
                dateInput.setText(sdf.format(new Date(selectedDate[0])));
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
        });

        new AlertDialog.Builder(this)
                .setView(dialogView)
                .setPositiveButton(R.string.save, (dialog, which) -> {
                    String weightStr = weightInput.getText().toString().trim();
                    if (weightStr.isEmpty()) return;
                    try {
                        double weight = Double.parseDouble(weightStr);
                        WeightEntry previousEntry = mViewModel.getLastWeight(this, mUserId);
                        mViewModel.addWeightEntry(this, mUserId, weight, selectedDate[0]);
                        checkGoalReached(previousEntry, weight);
                        refreshDashboard();
                    } catch (NumberFormatException ignored) {}
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // --- Goal notification ---

    private void checkGoalReached(WeightEntry previousEntry, double newWeight) {
        GoalWeight goal = mViewModel.getGoalWeight(this, mUserId);
        if (goal == null) return;

        double goalWeight = goal.getGoal();

        // If no previous entry, just check current
        if (previousEntry == null) {
            if (newWeight <= goalWeight &&
                    mViewModel.isNotificationsEnabled(this, mUserId)) {
                sendGoalNotification();
            }
            return;
        }

        double previousWeight = previousEntry.getWeight();

        // Only trigger when crossing the threshold
        if (previousWeight > goalWeight && newWeight <= goalWeight) {
            if (mViewModel.isNotificationsEnabled(this, mUserId)) {
                sendGoalNotification();
            }
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Goal Reached",
                    NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Notifies you when your goal weight is reached.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void sendGoalNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Goal Reached!")
                .setContentText("Congratulations! You have reached your goal weight.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, builder.build());
    }
}
